from django.urls import path
from .import views

app_name='Author'

urlpatterns=[
    path('create_user/',views.register,name='adduser'),
]
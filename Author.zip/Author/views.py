from django.shortcuts import render
from .forms import UserForm
from django.contrib.auth.models import User

# Create your views here.

def register(request):
    if request.method=='POST':
        user_form=UserForm(request.POST)
        if user_form.is_valid():
           username=request.POST.get('username')
           email=request.POST.get('email')
           password1=request.POST.get('password1')
           password2=request.POST.get('password2')
           user=User(username=username,email=email,password1=password1,password2=password2)
           user.save()
           return redirect("Post:posts")
    else:
        user_form=UserForm()
        return render(request,"User/userform.html",{'form':user_form})

